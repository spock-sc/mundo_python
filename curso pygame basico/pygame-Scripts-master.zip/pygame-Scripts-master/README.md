# pygame-Scripts

El cogido fuente tiene el mismo indice del video, es decir:

si el video dice: 
09: background el cogido fuente tendrá la misma enumeración. 09_background
